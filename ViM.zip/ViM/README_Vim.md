
# Vision Mamba (Vim)

This repository provides a working setup for evaluating the Vision Mamba model using pretrained weights on the ImageNet dataset.

## 🔧 Setup Instructions

### 1. Clone the Vim Repository
```bash
git clone https://github.com/hustvl/Vim
cd Vim
```

---

### 2. Install Dependencies

#### Python Requirements
Install base dependencies:
```bash
pip install -r vim/vim_requirements.txt
```

#### Additional Required Modules
```bash
# Install causal-conv1d
pip install -e ./causal-conv1d

# Install Mamba (version 1.1.1 compatible implementation)
pip install -e ./mamba-1p1p1
```

---

### 3. Download Pretrained Checkpoint

Download the pretrained Vision Mamba checkpoint:
```bash
wget https://huggingface.co/hustvl/Vim-small-midclstok/resolve/main/vim_s_midclstok_ft_81p6acc.pth
```

---

### 4. Prepare ImageNet Dataset

#### 4.1. Create Dataset Directory
```bash
mkdir image_dataset
cd image_dataset
```

#### 4.2. Download ImageNet Data (Requires Credentials or Access Rights)
```bash
# Download validation and training sets
wget https://image-net.org/data/ILSVRC/2012/ILSVRC2012_img_val.tar
wget https://image-net.org/data/ILSVRC/2012/ILSVRC2012_img_train.tar
```

#### 4.3. Extract Training Set
```bash
mkdir train && mv ILSVRC2012_img_train.tar train/
cd train
tar -xvf ILSVRC2012_img_train.tar && rm -f ILSVRC2012_img_train.tar

# Extract each class .tar file into its own folder
find . -name "*.tar" | while read -r NAME; do
    mkdir -p "${NAME%.tar}"
    tar -xvf "${NAME}" -C "${NAME%.tar}" && rm -f "${NAME}"
done
```

##### 🛠️ Optional Cleanup
Remove known corrupted or problematic images:
```bash
rm n04266014/n04266014_10835.JPEG
```

#### 4.4. Extract Validation Set
```bash
cd ..
mkdir val && mv ILSVRC2012_img_val.tar val/
cd val
tar -xvf ILSVRC2012_img_val.tar
```

#### 4.5. Prepare Validation Structure
Use the ImageNet validation preprocessing script:
```bash
wget -qO- https://raw.githubusercontent.com/soumith/imagenetloader.torch/master/valprep.sh | bash
```

---

### 5. Run Evaluation

Return to the `Vim` root directory:
```bash
cd ../../Vim
```

Run the evaluation command:
```bash
python ./vim/main.py --eval --resume ./vim_s_midclstok_ft_81p6acc.pth \
  --model vim_small_patch16_stride8_224_bimambav2_final_pool_mean_abs_pos_embed_with_midclstok_div2 \
  --data-path ./image_dataset
```

---

## 📌 Notes

- Ensure your Python version and CUDA setup are compatible with PyTorch and the dependencies.
- You **must have access to the ImageNet dataset** to download the train and val tar files.
- This guide uses the small variant of Vision Mamba with pretrained weights fine-tuned to achieve 81.6% top-1 accuracy.

---

## 📁 Directory Structure Overview
```
Vim/
├── causal-conv1d/
├── mamba-1p1p1/
├── vim/
│   ├── main.py
│   └── ...
├── vim_s_midclstok_ft_81p6acc.pth
└── image_dataset/
    ├── train/
    └── val/
```

---

## 📜 License & Acknowledgments

This setup is based on the official [Vim GitHub repository](https://github.com/hustvl/Vim). Pretrained models are hosted on [Hugging Face](https://huggingface.co/hustvl).
